# LimpaCel

App Android nativo (Kotlin + Jetpack Compose), sem root e sem anúncios, que
diagnostica o que está deixando o celular lento e recomenda ações — fazendo
sozinho o que o Android permite, e mostrando exatamente a tela certa do
sistema para o que exige ação manual.

## Como abrir

1. Instale o **Android Studio** (gratuito).
2. Abra a pasta `LimpaCel` como projeto.
3. Deixe o Gradle sincronizar (primeira vez baixa as dependências).
4. Rode em um emulador ou no celular com depuração USB ativada.

## O que já funciona

- **Armazenamento por app** (apk, dados, cache) via `StorageStatsManager`.
- **Tempo de uso em primeiro plano por app** (últimos 7 dias) via `UsageStatsManager`.
- **Motor de recomendações** com regras explicáveis (cache grande, apps
  parados ocupando espaço, apps muito usados que merecem checar otimização
  de bateria, pouco espaço livre no total).
- **Deep-links diretos**: cada recomendação abre a tela certa do sistema
  (configurações do app específico, armazenamento, otimização de bateria,
  acesso de uso) em vez de instruções genéricas.
- Limpeza do **próprio cache** do app (o único cache que um app pode apagar
  sem intervenção do usuário).

## Limitação importante (sem root)

O Android não permite, para nenhum app de terceiros, sem root:
- Limpar cache/dados de outros apps diretamente.
- Encerrar processos de outros apps em segundo plano.
- Ler uso de bateria por app com granularidade fina (isso é exclusivo do
  sistema e de apps assinados pelo fabricante).

Por isso essas ações são sempre **recomendadas com o deep-link certo**, e
a decisão final (limpar, desinstalar) é sempre do usuário.

## Primeira execução — permissão necessária

Para medir corretamente o tamanho de cada app e o tempo de uso, o app pede
a permissão especial `PACKAGE_USAGE_STATS`, concedida manualmente em
Configurações > Apps > Acesso especial > Acesso de uso. Sem ela, o app
ainda funciona, mas com números zerados para os apps de terceiros.

## Próximos passos sugeridos

- [ ] Tela dedicada de lista de apps ordenável (tamanho, tempo de uso, nome).
- [ ] Histórico/gráfico de evolução do espaço livre ao longo do tempo.
- [ ] Detecção de arquivos duplicados/grandes na pasta de Downloads (via
      `MediaStore`, sem precisar de permissão de armazenamento total).
- [ ] Notificação periódica (WorkManager) avisando quando o espaço livre
      cair abaixo de um limite.
- [ ] Ícone e identidade visual própria.

## Estrutura do código

```
app/src/main/java/com/limpacel/app/
├── MainActivity.kt              # UI (Compose)
├── model/AppInfo.kt             # modelos de dados
├── analyzer/
│   ├── StorageAnalyzer.kt       # uso de armazenamento por app
│   ├── UsageAnalyzer.kt         # tempo de uso e memória
│   ├── RecommendationEngine.kt  # regras que viram recomendações
│   └── SystemActionLauncher.kt  # abre a tela certa do sistema
```
