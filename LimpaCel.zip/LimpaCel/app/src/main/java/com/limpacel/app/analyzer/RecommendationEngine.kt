package com.limpacel.app.analyzer

import com.limpacel.app.model.ActionType
import com.limpacel.app.model.AppInfo
import com.limpacel.app.model.Recommendation
import com.limpacel.app.model.Severity

/**
 * Regras simples e explicáveis (nada de "score mágico" de caixa-preta).
 * Cada recomendação diz exatamente por quê foi gerada.
 */
object RecommendationEngine {

    private const val CACHE_ALTA_MB = 300L
    private const val DADOS_ALTO_MB = 1024L
    private const val DIAS_SEM_USO = 60L

    fun build(apps: List<AppInfo>, freeStorageBytes: Long, totalStorageBytes: Long): List<Recommendation> {
        val recs = mutableListOf<Recommendation>()
        val mb = 1024L * 1024L

        // 1) Pouco espaço livre no geral
        val freePercent = if (totalStorageBytes > 0) (freeStorageBytes * 100 / totalStorageBytes) else 100
        if (freePercent < 10) {
            recs += Recommendation(
                title = "Armazenamento quase cheio (${freePercent}% livre)",
                description = "Menos de 10% de espaço livre deixa o sistema mais lento para gravar arquivos temporários. Veja abaixo os apps que mais ocupam espaço.",
                severity = Severity.ALTA,
                actionLabel = "Abrir armazenamento do sistema",
                actionType = ActionType.OPEN_STORAGE_SETTINGS
            )
        }

        // 2) Apps de usuário (não-sistema) com cache alto
        apps.filter { !it.isSystemApp && it.cacheSizeBytes / mb > CACHE_ALTA_MB }
            .sortedByDescending { it.cacheSizeBytes }
            .take(10)
            .forEach { app ->
                recs += Recommendation(
                    title = "${app.label}: ${app.cacheSizeBytes / mb} MB de cache",
                    description = "Cache grande não acelera o app, só ocupa espaço. Pode limpar sem perder dados.",
                    severity = Severity.MEDIA,
                    targetPackage = app.packageName,
                    actionLabel = "Abrir e limpar cache",
                    actionType = ActionType.OPEN_APP_SETTINGS
                )
            }

        // 3) Apps de usuário com dados muito grandes e não usados há muito tempo
        apps.filter {
            !it.isSystemApp &&
            it.dataSizeBytes / mb > DADOS_ALTO_MB &&
            (it.daysSinceLastUse == null || it.daysSinceLastUse!! > DIAS_SEM_USO)
        }.sortedByDescending { it.dataSizeBytes }
            .take(10)
            .forEach { app ->
                recs += Recommendation(
                    title = "${app.label} ocupa ${app.dataSizeBytes / mb} MB e parece sem uso recente",
                    description = "Candidato a desinstalar se você não usa mais. Isso libera bem mais espaço do que só limpar cache.",
                    severity = Severity.MEDIA,
                    targetPackage = app.packageName,
                    actionLabel = "Ver app / desinstalar",
                    actionType = ActionType.UNINSTALL_APP
                )
            }

        // 4) Apps de usuário com muito tempo em primeiro plano — não é problema em si,
        // mas ajuda a identificar o que realmente usa bateria/dados, então sugerimos
        // revisão de otimização de bateria para os mais pesados.
        apps.filter { !it.isSystemApp && it.totalForegroundTimeMs > 0 }
            .sortedByDescending { it.totalForegroundTimeMs }
            .take(5)
            .forEach { app ->
                val horas = app.totalForegroundTimeMs / 3_600_000.0
                if (horas > 5) {
                    recs += Recommendation(
                        title = "${app.label}: %.1f h de uso nos últimos 7 dias".format(horas),
                        description = "Apps muito usados valem uma checagem na otimização de bateria do sistema, para garantir que não fiquem acordados em segundo plano sem necessidade.",
                        severity = Severity.BAIXA,
                        targetPackage = app.packageName,
                        actionLabel = "Ver otimização de bateria",
                        actionType = ActionType.OPEN_BATTERY_OPTIMIZATION
                    )
                }
            }

        return recs.sortedBy { it.severity.ordinal }
    }
}
