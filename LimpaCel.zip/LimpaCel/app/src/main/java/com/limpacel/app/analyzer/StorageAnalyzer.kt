package com.limpacel.app.analyzer

import android.app.AppOpsManager
import android.app.usage.StorageStats
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import com.limpacel.app.model.AppInfo

/**
 * Mede uso de armazenamento (apk + dados + cache) por app instalado.
 * Requer a permissão especial PACKAGE_USAGE_STATS concedida pelo usuário
 * (sem ela, cada app só enxerga os próprios dados por sandbox do Android).
 */
class StorageAnalyzer(private val context: Context) {

    fun hasUsageAccessPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Lista todos os apps instalados (não só os de usuário) com uso de armazenamento. */
    fun analyzeInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val storageStatsManager = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val storageManager = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val canReadStats = hasUsageAccessPermission()

        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        return installedApps.mapNotNull { appInfo: ApplicationInfo ->
            try {
                val label = pm.getApplicationLabel(appInfo).toString()
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                var apkSize = 0L
                var dataSize = 0L
                var cacheSize = 0L

                if (canReadStats && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val uuid = storageManager.getUuidForPath(context.filesDir)
                    val stats: StorageStats = storageStatsManager.queryStatsForUid(uuid, appInfo.uid)
                    apkSize = stats.appBytes
                    dataSize = stats.dataBytes
                    cacheSize = stats.cacheBytes
                }

                AppInfo(
                    packageName = appInfo.packageName,
                    label = label,
                    isSystemApp = isSystem,
                    apkSizeBytes = apkSize,
                    dataSizeBytes = dataSize,
                    cacheSizeBytes = cacheSize
                )
            } catch (e: Exception) {
                null // alguns pacotes de sistema recusam leitura; ignora silenciosamente
            }
        }.sortedByDescending { it.totalSizeBytes }
    }

    /** Espaço livre e total do armazenamento interno, em bytes. */
    fun getInternalStorageStatus(): Pair<Long, Long> {
        val stat = android.os.StatFs(context.filesDir.path)
        val free = stat.availableBytes
        val total = stat.totalBytes
        return free to total
    }
}
