package com.limpacel.app.analyzer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.limpacel.app.model.ActionType
import com.limpacel.app.model.Recommendation

/**
 * Dispara o Intent certo do sistema para cada recomendação.
 * O app nunca finge executar a ação sozinho quando não pode — sempre leva
 * o usuário direto para a tela nativa correspondente.
 */
object SystemActionLauncher {

    fun execute(context: Context, recommendation: Recommendation) {
        val intent = when (recommendation.actionType) {
            ActionType.OPEN_APP_SETTINGS, ActionType.UNINSTALL_APP -> {
                val pkg = recommendation.targetPackage ?: return
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", pkg, null)
                }
            }
            ActionType.OPEN_STORAGE_SETTINGS ->
                Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)

            ActionType.OPEN_BATTERY_OPTIMIZATION ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                else
                    Intent(Settings.ACTION_SETTINGS)

            ActionType.OPEN_USAGE_ACCESS_SETTINGS ->
                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

            ActionType.CLEAR_OWN_CACHE -> {
                context.cacheDir.deleteRecursively()
                return
            }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
