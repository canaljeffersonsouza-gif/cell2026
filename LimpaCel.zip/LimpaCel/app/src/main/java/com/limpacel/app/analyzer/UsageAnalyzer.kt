package com.limpacel.app.analyzer

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.concurrent.TimeUnit

/**
 * Tempo de uso em primeiro plano por app (últimos 7 dias) e detecção de apps
 * atualmente ativos em segundo plano. Sem root, o Android só revela processos
 * do próprio app a partir do Android 8 — então aqui focamos em tempo de uso,
 * que é o indicador mais confiável do que realmente consome recursos.
 */
class UsageAnalyzer(private val context: Context) {

    /** Mapa packageName -> tempo total em primeiro plano (ms) nos últimos [days] dias. */
    fun getForegroundTimePerApp(days: Int = 7): Map<String, Long> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - TimeUnit.DAYS.toMillis(days.toLong())

        val stats = usm.queryAndAggregateUsageStats(start, end)
        return stats.mapValues { it.value.totalTimeInForeground }
    }

    /** RAM livre e total do sistema, em bytes — indicador direto de pressão de memória. */
    fun getMemoryStatus(): ActivityManager.MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info
    }
}
