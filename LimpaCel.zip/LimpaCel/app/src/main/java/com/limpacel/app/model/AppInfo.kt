package com.limpacel.app.model

/** Dados consolidados de um app instalado, usados para diagnóstico e ranking. */
data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystemApp: Boolean,
    val apkSizeBytes: Long = 0L,
    val dataSizeBytes: Long = 0L,
    val cacheSizeBytes: Long = 0L,
    val lastUsedTimestamp: Long = 0L,   // 0 = desconhecido/nunca medido
    val totalForegroundTimeMs: Long = 0L,
    val isRunningInBackground: Boolean = false
) {
    val totalSizeBytes: Long get() = apkSizeBytes + dataSizeBytes + cacheSizeBytes

    val daysSinceLastUse: Long?
        get() = if (lastUsedTimestamp == 0L) null
                else (System.currentTimeMillis() - lastUsedTimestamp) / 86_400_000L
}

/** Uma recomendação acionável — o que o app NÃO consegue fazer sozinho, mas pode guiar o usuário a fazer. */
data class Recommendation(
    val title: String,
    val description: String,
    val severity: Severity,
    val targetPackage: String? = null,   // se vazio, não há deep-link de app específico
    val actionLabel: String,             // ex: "Abrir configurações do app"
    val actionType: ActionType
)

enum class Severity { ALTA, MEDIA, BAIXA }

enum class ActionType {
    OPEN_APP_SETTINGS,        // tela "Sobre o app" de um app específico
    OPEN_STORAGE_SETTINGS,    // tela geral de armazenamento do sistema
    OPEN_BATTERY_OPTIMIZATION,// tela de otimização de bateria
    OPEN_USAGE_ACCESS_SETTINGS, // conceder PACKAGE_USAGE_STATS
    UNINSTALL_APP,             // dispara o intent de desinstalação
    CLEAR_OWN_CACHE            // ação que o app PODE fazer sozinho (seu próprio cache)
}
